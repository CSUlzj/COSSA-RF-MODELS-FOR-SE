function [Best_pos, Best_score, curve, avcurve] = SSA(numm,pop, Max_iter, lb, ub, dim, fobj)

%%  ��������       
ST = 0.8;                    % Ԥ��ֵ
PD = 0.2;                    % �����ߵı��У�ʣ�µ��Ǽ�����
PDNumber = pop * PD;         % ����������
SDNumber = pop - pop * PD;   % ��ʶ����Σ����ȸ����

%%  �ж��Ż���������
if(max(size(ub)) == 1)
   ub = ub .* ones(1, dim);
   lb = lb .* ones(1, dim);  
end

% %%  ��Ⱥ��ʼ��
% pop_lsat = initialization(pop, dim, ub, lb);
% pop_new  = pop_lsat;

%Initialize the positions of search agents
lb=lb.*ones(1,dim);
ub=ub.*ones(1,dim);

pop_lsat = repmat(lb, pop, 1)+chaos(numm,pop,dim) .* repmat((ub-lb), pop, 1);
pop_new  = pop_lsat;



%%  �����ʼ��Ӧ��ֵ
fitness = zeros(1, pop);
for i = 1 : pop
   fitness(i) =  fobj(pop_new(i, :));
end

%%  �õ�ȫ��������Ӧ��ֵ
[fitness, index]= sort(fitness);
GBestF = fitness(1); 

%%  �õ�ȫ��������Ⱥ
for i = 1 : pop
    pop_new(i, :) = pop_lsat(index(i), :);
end

GBestX = pop_new(1, :);
X_new  = pop_new;

%%  �Ż��㷨
for i = 1: Max_iter

   BestF = fitness(1);
   R2 = rand(1);

   for j = 1 : PDNumber
      if(R2 < ST)
          X_new(j, :) = pop_new(j, :) .* exp(-j / (rand(1) * Max_iter));
      else
          X_new(j, :) = pop_new(j, :) + randn() * ones(1, dim);
      end     
   end
   
   for j = PDNumber + 1 : pop
        if(j > (pop - PDNumber) / 2 + PDNumber)
          X_new(j, :) = randn() .* exp((pop_new(end, :) - pop_new(j, :)) / j^2);
        else
          A = ones(1, dim);
          for a = 1 : dim
              if(rand() > 0.5)
                A(a) = -1;
              end
          end
          AA = A' / (A * A');     
          X_new(j, :) = pop_new(1, :) + abs(pop_new(j, :) - pop_new(1, :)) .* AA';
       end
   end
   
   Temp = randperm(pop);
   SDchooseIndex = Temp(1 : SDNumber); 
   
   for j = 1 : SDNumber
       if(fitness(SDchooseIndex(j)) > BestF)
           X_new(SDchooseIndex(j), :) = pop_new(1, :) + randn() .* abs(pop_new(SDchooseIndex(j), :) - pop_new(1, :));
       elseif(fitness(SDchooseIndex(j)) == BestF)
           K = 2 * rand() -1;
           X_new(SDchooseIndex(j), :) = pop_new(SDchooseIndex(j), :) + K .* (abs(pop_new(SDchooseIndex(j), :) - ...
               pop_new(end, :)) ./ (fitness(SDchooseIndex(j)) - fitness(end) + 10^-8));
       end
   end

%%  �߽����
   for j = 1 : pop
       for a = 1 : dim
           if(X_new(j, a) > ub(a))
              X_new(j, a) = ub(a);
           end
           if(X_new(j, a) < lb(a))
              X_new(j, a) = lb(a);
           end
       end
   end 

%%  ��ȡ��Ӧ��ֵ
   for j = 1 : pop
    fitness_new(j) = fobj(X_new(j, :));
   end
   
%%  ��ȡ������Ⱥ
   for j = 1 : pop
       if(fitness_new(j) < GBestF)
          GBestF = fitness_new(j);
          GBestX = X_new(j, :);
       end
   end
   
%%  ������Ⱥ����Ӧ��ֵ
   pop_new = X_new;
   fitness = fitness_new;

%%  ������Ⱥ 
   [fitness, index] = sort(fitness);
   for j = 1 : pop
      pop_new(j, :) = pop_new(index(j), :);
   end

%%  �õ��Ż�����
   curve(i) = GBestF;
   avcurve(i) = sum(curve) / length(curve);
end

%%  �õ�����ֵ
Best_pos = [round(GBestX(1: 2))] ;
Best_score = curve(end);