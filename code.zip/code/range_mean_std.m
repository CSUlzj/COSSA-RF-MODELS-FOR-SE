clc
clear all
warning off
% 读取数据文件
data = readmatrix('SE-160.xlsx'); % 假设数据保存在名为 data.csv 的文件中

% 初始化结果矩阵
[numRows, numCols] = size(data);
ranges = zeros(numCols, 2);
means = zeros(numCols, 1);
stds = zeros(numCols, 1);

% 计算每列数据的 Range, Mean, Std
for i = 1:numCols
    columnData = data(:, i);
    columnMin = min(columnData);
    columnMax = max(columnData);
    columnMean = mean(columnData);
    columnStd = std(columnData);
    
    % 将结果存储在结果矩阵中
    ranges(i, :) = [columnMin, columnMax];
    means(i) = columnMean;
    stds(i) = columnStd;
end

% 输出结果
disp('Column | Range (Min, Max) | Mean | Std');
for i = 1:numCols
    fprintf('Col %d | [%f, %f] | %f | %f\n', i, ranges(i, 1), ranges(i, 2), means(i), stds(i));
end

% 如果需要将结果保存到文件中，可以使用 writematrix 和 writetable 函数
results = table(ranges(:,1), ranges(:,2), means, stds, 'VariableNames', {'Min', 'Max', 'Mean', 'Std'});
writetable(results, 'results.csv'); % 将结果保存为 results.csv 文件

