function Y_hat = regRF_predict(X,model)

%% 判断输入值
if nargin~=2
    error('need atleast 2 parameters,X matrix and model');
end
    
%% 得到预测值
Y_hat = mexRF_predict(X',model.lDau,model.rDau,model.nodestatus,...
                      model.nrnodes,model.upper,model.avnode,model.mbest,model.ndtree,model.ntree);

%% 得到输出
if ~isempty(find(model.coef, 1))
    Y_hat = model.coef(1) + model.coef(2)*Y_hat;
end

clear mexRF_predict